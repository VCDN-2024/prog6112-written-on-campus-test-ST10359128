/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lab_services_student
 */

// Implementing the IRoadAccidents interface with an abstract class
abstract class RoadAccidents implements IRoadAccidents {
    private String vehicleType;
    private String city;
    private int accidentTotal;

    // Initializing the vehicle type, city, and accident total
    public RoadAccidents(String vehicleType, String city, int accidentTotal) {
        this.vehicleType = vehicleType;
        this.city = city;
        this.accidentTotal = accidentTotal;
    }
    
    public String getAccidentVehicleType() {
        return vehicleType;
    }

    public String getCity() {
        return city;
    }

    public int getAccidentTotal() {
        return accidentTotal;
    }

    // Printing the report
    public abstract void printAccidentReport();
}

// Subclass RoadAccidentReport
class RoadAccidentReport extends RoadAccidents {

    // Constructor
    public RoadAccidentReport(String vehicleType, String city, int accidentTotal) {
        super(vehicleType, city, accidentTotal);
    }

    // Printing the accident report with the abstract method
    @Override
    public void printAccidentReport() {
        System.out.println("VEHICLE ACCIDENT REPORT:");
        System.out.println("*************************");
        System.out.println("VEHICLE TYPE: " + getAccidentVehicleType());
        System.out.println("CITY: " + getCity());
        System.out.println("ACCIDENT TOTAL: " + getAccidentTotal());
        System.out.println("*************************");
    }
}

// RunApplication class
public class AccidentReport {
    public static void main(String[] args) {
        // Instances of RoadAccidentReport
        RoadAccidentReport carReport = new RoadAccidentReport("Car", "Cape Town", 155);
        RoadAccidentReport motorbikeReport = new RoadAccidentReport("Motorbike", "Johannesburg", 145);

        // Displaying
        carReport.printAccidentReport();
        System.out.println("------------------------------");
        motorbikeReport.printAccidentReport();
    }
}

