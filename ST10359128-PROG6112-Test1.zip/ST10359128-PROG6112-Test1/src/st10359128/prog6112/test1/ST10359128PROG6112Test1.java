/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10359128.prog6112.test1;
import java.util.Scanner;
/**
 *
 * @author lab_services_student
 */
public class ST10359128PROG6112Test1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);
        
        // Arrays to store city names, car accidents, and motorbike accidents
        String[] cities = {"Cape Town", "Johannesburg", "Port Elizabeth"};
        int[][] accidents = new int[3][2];

        // The users input for all the stats
        for (int i = 0; i < cities.length; i++) {
            System.out.println("Enter the number of car accidents for " + cities[i] + ": ");
            accidents[i][0] = scanner.nextInt();

            System.out.println("Enter the number of motorbike accidents for " + cities[i] + ": ");
            accidents[i][1] = scanner.nextInt();
        }

        // Accident report
        System.out.println("--------------------------------");
        System.out.println("\nROAD ACCIDENT REPORT:");
        System.out.println("--------------------------------");
        for (int i = 0; i < cities.length; i++) {
            System.out.printf("%s, CAR-%d, MOTOR BIKE-%d\n", cities[i], accidents[i][0], accidents[i][1]);
        }

        
        // Road Accident Totals for each city
        System.out.println("--------------------------------");
        System.out.println("\nROAD ACCIDENT TOTALS FOR EACH CITY:");
        System.out.println("--------------------------------");
        for (int i = 0; i < cities.length; i++) {
            int totalAccidents = accidents[i][0] + accidents[i][1];
            System.out.printf("%s:  %d\n", cities[i], totalAccidents);
        }
        
        // City with highest amount of accidents
        int maxAccidents = 0;
        String maxCity = "";
        for (int i = 0; i < cities.length; i++) {
            int totalAccidents = accidents[i][0] + accidents[i][1];
            if (totalAccidents > maxAccidents) {
                maxAccidents = totalAccidents;
                maxCity = cities[i];
            }
        }
        
        //Displaying 
        System.out.println("\nCITY WITH THE MOST VEHICLE ACCIDENTS: " + maxCity + " with " + maxAccidents + " accidents.");
        System.out.println("--------------------------------");
        scanner.close();
    }
    
}
